/** Automatically generated file. DO NOT MODIFY */
package com.ionicframework.myapp560377;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}