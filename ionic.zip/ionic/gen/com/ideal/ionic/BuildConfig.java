/** Automatically generated file. DO NOT MODIFY */
package com.ideal.ionic;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}