$(function(){
    
    $( "#popup-outside-page" ).enhanceWithin().popup();
    
    $('#numberMax').raty();
    $('#numberMax').raty({
        numberMax : 5,
        number    : 100,
        starOff : 'images/star-off.png',
        starOn  : 'images/star-on.png',
        click: function(score, evt) {
            LOGIN.localVar.ratingCount = score;
            console.log('ID: ' + this.id + "\nscore: " + score + "\nevent: " + evt);
            return true;
          }
      });
   $( "#popup-outside-page" ).popup({
        dismissible: false,
        positionTo: "window"
        });
    $( "#add_rating_btn" ).on( "tap",HOME.sentimentRating);
    
    
    var loading = false;
    $( "#recall" ).on( "pageshow", function( event, ui ) {
        $('#pullscrollRecall').scrollz('hidePullHeader');
        console.log("xxxxxxxx");
        $('#pullscrollRecall').scrollz({
            pull: true
          });
        $( "#recall" ).trigger( "updatelayout" );
    });
    
    $( "#warning" ).on( "pageshow", function( event, ui ) {
        $('#pullscrollWarning').scrollz('hidePullHeader');
        console.log("xxxxxxxx");
        $('#pullscrollWarning').scrollz({
            pull: true
          });
        $( "#warning" ).trigger( "updatelayout" );
    });
   
    
    
    $( "#login_btn" ).on( "tap", LOGIN.validateLogin );
    $( "#registration_btn" ).on( "tap", REGISTERUSER.validateField);
    $( "#logout_btn" ).on( "tap", LOGIN.logOutAccount);
    $( "#forgot_submit_btn" ).on( "tap", REGISTERUSER.forgotPassword);
    $( "#location_menu" ).on( "tap",function(){
        $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#location", { role: "page",transition: "slide", reverse: false  } );
        LOCATION.getPreLocation();
    });//menu 
    $( ".menu-home-btn-functional" ).on( "tap",function(){
        if($.mobile.activePage.is("#home"))
            console.log("home screen");
        else
            HOME.homeInit();
    });//menu 

 
    //location
    
    $( "#location" ).on( "pagecreate", function( event, ui ) {
        if(app.checkNetwork() == true){
            LOCATION.getMyCurrentLocation(function(g){
                console.log("getMyCurrentLocation ==>"+g);
            });
        }
        //$( "#location_btn" ).on( "tap", LOCATION.getMyCurrentLocation);
        $( "#add_lok_submit_btn" ).on( "tap", LOCATION.addNewLocation);
        $("#record_new_location_btn").on( "tap", LOCATION.recordCurrentLocation);//
        
        $("#new_location_btn").on( "tap", function() {
            $("#lock_name_txt").val("");
            $("#lock_street1_txt").val("");
            $("#lock_street2_txt").val("");
            $("#lock_zip_txt").val("");
            $("#lock_city_txt").val("");
            
            LOCATION.localVar.addNewLocationFlage = true;
            $('#drplwn_lock_state').val("").selectmenu();
            $('#drplwn_lock_state').val("").selectmenu('refresh');
            
        });//
        
        LOCATION.getStateList();//get state list for add new location;
    } );
    
    $( "#addlocation" ).on( "pagecreate", function( event, ui ) {
        $("#drplwn_lock_state-button").addClass("ui-nodisc-icon").addClass("ui-alt-icon");
        
    });

    
    $( "#preferences" ).on( "pagebeforeshow", function( event, ui ) {
        console.log("preferences pagecontainershow");
        PREFERENCE.getUserDetails(); 
        
    });
   
    
    $("#add_newdrug_btn").on( "click", function() {
        
        $(".addAutoPreferences_lbl").text("Add Drug");
        $("#addauto_preferences_btn").text("Add");
        
        PREFERENCE.localVar.selectedManufactureId = 0;
        PREFERENCE.localVar.addEditFlage = null; //for add record

        $("#autocomplete").html("");
        $("#autocomplete").height(0);
        $( "#autocomplete" ).filterable();
        $( "#autocomplete" ).filterable( "refresh" );
        
        $("#add_manufacture_name_txt").val("");
        $("#add_drug_name_txt").val("");
        
        $( "#drplwn_drivetrain" ).addClass("ui-state-disabled");
        $( "#drplwn_drivetrain" ).attr( "disabled", "disabled" );
        $( "#drplwn_manufacture" ).addClass("ui-state-disabled");
        $( "#drplwn_manufacture" ).attr( "disabled", "disabled" );
        
       
        var obj=document.getElementById("drplwn_drivetrain"); 
        while(obj.length != 0){
                obj.remove(0);
            }
        $('#drplwn_drivetrain').append('<option value="" selected="selected">Strength</option>');
         
        var obj1=document.getElementById("drplwn_manufacture");
        while(obj1.length != 0){
            obj1.remove(0);
            }
        $('#drplwn_manufacture').append('<option value="" selected="selected">Route</option>');
        
        
        $( "select" ).selectmenu();
        $('#drplwn_drivetrain').val("").selectmenu('refresh');
        $('#drplwn_manufacture').val("").selectmenu('refresh');
        
    });
    
    $( "#preferences" ).on( "pagecreate", function( event, ui ) {
       
        $("#user_preferences_btn").on("tap",PREFERENCE.updateUserDetails);
        
        $(".user-preferences").on("tap",function(){
            $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#preferences", { role: "page",transition: "pop", reverse: false  } );
            
        });
        $(".auto-preferences").on("tap",function(){ // drug  preferences tab
            $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#autoPreferences", { role: "page",transition: "pop", reverse: false  } );
            PREFERENCE.UserDrugPreference.getPreviousDrugPreference();
        });
    });
    
    
    $( document ).on( "pagecreate", "#addAutoPreferences", function() {
        
        $("#drplwn_trim-button").addClass("ui-nodisc-icon").addClass("ui-alt-icon");
        $("#drplwn_drivetrain-button").addClass("ui-nodisc-icon").addClass("ui-alt-icon");
        $("#drplwn_manufacture-button").addClass("ui-nodisc-icon").addClass("ui-alt-icon");

            $( "#autocomplete" ).on( "filterablebeforefilter", function ( e, data ) {
                var $ul = $( this ),
                $input = $( data.input ),
                value = $input.val(),
                html = "";
                $ul.html( "" );
                
                if($("#add_manufacture_name_txt").val() == ""){
                    PREFERENCE.localVar.selectedManufactureId = 0;
                    console.log("add_manufacture_name_txt is empty");
                   // $("#add_newdrug_btn").trigger('click');
                    
                    PREFERENCE.localVar.selectedManufactureId = 0;
                   
                    $("#autocomplete").html("");
                    $("#autocomplete").height(0);
                    $( "#autocomplete" ).filterable();
                    $( "#autocomplete" ).filterable( "refresh" );
                    
                    $("#add_manufacture_name_txt").val("");
                    $("#add_drug_name_txt").val("");
                    
                    $( "#drplwn_drivetrain" ).addClass("ui-state-disabled");
                    $( "#drplwn_drivetrain" ).attr( "disabled", "disabled" );
                    $( "#drplwn_manufacture" ).addClass("ui-state-disabled");
                    $( "#drplwn_manufacture" ).attr( "disabled", "disabled" );
                    
                   
                    var obj=document.getElementById("drplwn_drivetrain"); 
                    while(obj.length != 0){
                            obj.remove(0);
                        }
                    $('#drplwn_drivetrain').append('<option value="" selected="selected">Strength</option>');
                     
                    var obj1=document.getElementById("drplwn_manufacture");
                    while(obj1.length != 0){
                        obj1.remove(0);
                        }
                    $('#drplwn_manufacture').append('<option value="" selected="selected">Route</option>');
                    
                    
                    $( "select" ).selectmenu();
                    $('#drplwn_drivetrain').val("").selectmenu('refresh');
                    $('#drplwn_manufacture').val("").selectmenu('refresh');
                    
                    
                    $ul.height(0);
                    $ul.listview( "refresh" );
                    $ul.trigger( "updatelayout");
               }
                
                if ( value && value.length > 2 ) {
                   
                    var PostData = constVariable.urlMethod.get('manufacture')+'query='+$input.val()+'&page='+PREFERENCE.localVar.manufacturePageId;
                    app.XMLHTTP.httpPostAjax(null, "GET", PostData, function(jsonData) {
                        app.loaderStop();
                        
                        if(jsonData ==10 ){
                            PREFERENCE.localVar.manufactureSearchPagedWebSearchText = $input.val();
                            PREFERENCE.localVar.manufacturePageId = 2;
                        }
                        
                        for ( var int in jsonData) {
                            html += '<li onclick="PREFERENCE.UserDrugPreference.getManufactureList('+jsonData[int].pdas_manufacturer_id+',this)">' + jsonData[int].manufacturer_name + '</li>';
                        }
                        $ul.html( html );
                        if(jsonData.length > 0)
                            $ul.height((app.getDeviceHeight()*35)/100);
                        
                        $ul.css("overflow","scroll");
                        $ul.listview( "refresh" );
                        $ul.trigger( "updatelayout");
                    })
                    
                }else{
                    $ul.height(0);
                    $ul.listview( "refresh" );
                    $ul.trigger( "updatelayout");
                }
            });
            /*****************************For Drug product*****************************/
            
            $( "#drugautocomplete" ).on( "filterablebeforefilter", function ( e, data ) {
                var $ul = $( this ),
                $input = $( data.input ),
                value = $input.val(),
                html = "";
                $ul.html( "" );
                
                if($("#add_drug_name_txt").val() == ""){
                    
                    $("#autocomplete").height(0);
                    $("#autocomplete").listview( "refresh" );
                    $("#autocomplete").trigger( "updatelayout");
                    
                    console.log("add_drug_name_txt is empty");
                    $( "#drplwn_drivetrain" ).addClass("ui-state-disabled");
                    $( "#drplwn_drivetrain" ).attr( "disabled", "disabled" );
                    $( "#drplwn_manufacture" ).addClass("ui-state-disabled");
                    $( "#drplwn_manufacture" ).attr( "disabled", "disabled" );
                    
                   
                    var obj=document.getElementById("drplwn_drivetrain"); 
                    while(obj.length != 0){
                            obj.remove(0);
                        }
                    $('#drplwn_drivetrain').append('<option value="" selected="selected">Strength</option>');
                     
                    var obj1=document.getElementById("drplwn_manufacture");
                    while(obj1.length != 0){
                        obj1.remove(0);
                        }
                    $('#drplwn_manufacture').append('<option value="" selected="selected">Route</option>');
                    
                    
                    
                    $('#drplwn_drivetrain').val("").selectmenu('refresh');
                    $('#drplwn_manufacture').val("").selectmenu('refresh');
                    $ul.height(0);
                    $ul.listview( "refresh" );
                    $ul.trigger( "updatelayout");
                    
                }
                
                if ( value && value.length > 2 ) {
                    var PostData = constVariable.urlMethod.get('productSearch')+'query='+$input.val()+'&ManufacturerId='+PREFERENCE.localVar.selectedManufactureId+'&page='+PREFERENCE.localVar.drugPageId;
                    app.XMLHTTP.httpPostAjax(null, "GET", PostData, function(jsonData) {
                        app.loaderStop();
                        PREFERENCE.localVar.selected_drugObj = jsonData;
                        
                        if(jsonData.length == 10)
                            PREFERENCE.localVar.productSearchPagedWebSearchText = $input.val();
                        
                        for ( var int in jsonData) {
                            html += '<li onclick="PREFERENCE.UserDrugPreference.getDrugsList('+int+',this)">'+ jsonData[int].md_user_display+ '</li>';
                        }
                        console.log(html);
                        $ul.html( html );
                        if(jsonData.length > 0)
                            $ul.height((app.getDeviceHeight()*35)/100);
                        
                        $ul.css("overflow","scroll");
                        $ul.listview( "refresh" );
                        $ul.trigger( "updatelayout");
                    })
                    
                } else{
                    $ul.height(0);
                    $ul.listview( "refresh" );
                    $ul.trigger( "updatelayout");
                }
            });
        });
        
        $('#drplwn_drivetrain').change(function() {
            console.log("drplwn_drivetrain changeEvent ==> "+$("#drplwn_drivetrain option:selected").val());
            
            var route = $("#drplwn_drivetrain option:selected").val();
            
            var obj=document.getElementById("drplwn_manufacture");  
            while(obj.length != 0){
                obj.remove(0);
                $('#drplwn_manufacture').val("").selectmenu('refresh');
                }
            
            
            var drugObj = PREFERENCE.localVar.selected_drugObj;
            var ProductNDC = drugObj.ProductNDC;
            console.log("ProductNDC"+ProductNDC.length);
            for( var int in ProductNDC) {
                console.log("ProductNDC[int].pdas_product_ndc_id"+ProductNDC[int].pdas_product_ndc_id);

                var tempRoute = ProductNDC[int].Route;
                
                console.log("-----------tempRoute----------"+tempRoute);
                
                for (var int1 = 0; int1 < tempRoute.length; int1++) {
                    opt = document.createElement("option");
                    opt.value = tempRoute[int1].route_code;
                    opt.text = tempRoute[int1].description;
                    obj.appendChild(opt);
                    /* opt.id = jsonData[int].CountryId*/
                } 
                removeDuplicateOptions('drplwn_manufacture');
                $('#drplwn_manufacture').selectmenu();
                $('#drplwn_manufacture').val("").selectmenu('refresh');
                
                
                $( "#drplwn_manufacture" ).removeClass("ui-state-disabled");
                $( "#drplwn_manufacture" ).attr( "disabled", "" );
                $( "#drplwn_manufacture" ).selectmenu( "enable" );
                $('#drplwn_manufacture').val("").selectmenu('refresh');
                
                

            }
            
        });
        $("#addauto_preferences_btn").on("tap",PREFERENCE.UserDrugPreference.addDrugPreference) // drug  preferences tab
        
        $("#nextRecall").on("tap",function(){
            HOME.localVar.recallPageCount++;
            console.log(HOME.localVar.recallPageCount);
        });
        $("#prevRecall").on("tap",function(){
            HOME.localVar.recallPageCount--;
            console.log(HOME.localVar.recallPageCount);
        });
        
        $("#nextWarning").on("tap",function(){
            HOME.localVar.warningPageCount++;
            console.log(HOME.localVar.warningPageCount);
        });
        $("#prevWarning").on("tap",function(){
            HOME.localVar.warningPageCount--;
            console.log(HOME.localVar.warningPageCount);
        });
        
      
        
  });

function removeDuplicateOptions(selectNode) {
    if (typeof selectNode === "string") {
        selectNode = document.getElementById(selectNode);
    }

    var seen = {},
        options = [].slice.call(selectNode.options),
        length = options.length,
        previous,
        option,
        value,
        text,
        i;

    for (i = 0; i < length; i += 1) {
        option = options[i];
        value = option.value,
        text = option.firstChild.nodeValue;
        previous = seen[value];
        if (typeof previous === "string" && text === previous) {
            selectNode.removeChild(option);
        } else {
            seen[value] = text;
        }
    }
}
        
/********************************************************************
 *                              LOGIN METHODE
 ********************************************************************/

var LOGIN = {
        localVar: {
            userName: null,
            userId: null,
            authId: null,
            lastName: null,
            loginCount: false,
            panel: false,
            password: null,
            ratingCount: 0,
            ratingElement:null,
        },//localVar
        logOutAccount: function(event) {
            LOGIN.localVar.userId = null;
            LOGIN.localVar.userName = null;
            LOGIN.localVar.lastName = null;
            LOGIN.localVar.authId = null;
            $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#login", { role: "page",transition: "slide", reverse: true  } );
       
        },
        validateLogin: function(event) {
            
            if($("#login_username_txt").val() == ""){
                app.Toast.show(validationMsg.logUserName());
            }else if( $("#login_password_txt").val() == ""){
                app.Toast.show(validationMsg.logPassword());
            }else{
                LOGIN.localVar.password = $("#login_password_txt").val();
                    var logData = {
                            "pdas_user_id":0.0,
                            "first_name":null,
                            "last_name":null,
                            "email_address":null,
                            "postal_area":null,
                            "postal_area_2":null,
                            "password":$("#login_password_txt").val(),
                            "status":null,
                            "role":null,
                            "authentication_id":$("#login_username_txt").val()
                            
                    }
                    LOGIN.getLogin(logData);
                
            }

        },//validateLogin
        
        getLogin: function(logData) {
            app.loaderStart("", "Please Wait...");
            var PostData = constVariable.urlMethod.get('login');
            try{
               app.XMLHTTP.httpPostAjax(logData, "POST", PostData, function(jsonData) {
                    LOGIN.loginSuccess(jsonData);
                    app.loaderStop();
                    
                })
            }catch (e) {
                console.log("Error"+e);
            }
        },//getLogin
        loginSuccess: function(jsonData) {
            LOGIN.localVar.userId = jsonData.pdas_user_id;
            LOGIN.localVar.userName = jsonData.first_name;
            LOGIN.localVar.lastName = jsonData.last_name;
            LOGIN.localVar.authId = jsonData.authentication_id;
            if( LOGIN.localVar.userId == null || typeof(LOGIN.localVar.userId) == "undefined"){
                console.log(" LOGIN.localVar.userId ==> "+ LOGIN.localVar.userId);
            }else{
                $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#home", { role: "page",transition: "slide"  } );
                LOGIN.keepLogin();
            }
            
            
        },
        keepLogin: function() {
            HOME.homeInit();
            
            if($(".keep-melogin").is(":checked")){
               
              console.log("YESSSSSSSSSSSSSS");
              try{
                  app.db.transaction(function(tx){
                      tx.executeSql('SELECT * FROM LOGIN',  [], function(tx,results){
                          if(results.rows.length == 0){
                              tx.executeSql('INSERT INTO LOGIN(PDAID,FIRSTNAME,LASTNAME,PASSWORD,AITHID,KEEPLOGINSTATUS)'
                                      +'VALUES("'+LOGIN.localVar.userId+'","'+LOGIN.localVar.userName+'","'+LOGIN.localVar.lastName+'","'+$("#login_password_txt").val()+'","'+LOGIN.localVar.authId+'","1")',[],function(){
                                          
                                      });
                         }else{
                             tx.executeSql('UPDATE LOGIN SET PDAID="'+LOGIN.localVar.userId+'",FIRSTNAME="'+LOGIN.localVar.userName+'",LASTNAME="'+LOGIN.localVar.lastName+'",PASSWORD="'+LOGIN.localVar.password+'",KEEPLOGINSTATUS="1"');
                          }
                      });
                  });
              }catch (e) {
                  console.log("Error"+e);
            }
            }else{
                console.log("NOOOOOOOOOOOOO");
                
                app.db.transaction(function(tx){
                    tx.executeSql('SELECT * FROM LOGIN',  [], function(tx,results){
                        if(results.rows.length > 0){
                            tx.executeSql('UPDATE LOGIN SET PDAID="'+LOGIN.localVar.userId+'",FIRSTNAME="'+LOGIN.localVar.userName+'",LASTNAME="'+LOGIN.localVar.lastName+'",PASSWORD="'+$("#login_password_txt").val()+'",KEEPLOGINSTATUS="0"');
                        }
                    });
                });
            }
        },              
}



var REGISTERUSER = {
        localVar: {
            
        },//localVar
        
        validateField: function() {
           
            var mypass = $("#reg_pass_txt").val();
            
            if($("#user_name_txt").val() == ""){
                app.Toast.show(validationMsg.logUserName());
            }else if($("#last_name_txt").val() == ""){
                app.Toast.show(validationMsg.logLastName());
            }else if($("#reg_email_txt").val() == ""){
                app.Toast.show(validationMsg.logEmail());
            }else if(app.validEmail($("#reg_email_txt").val()) == false){
                //app.Toast.show("Please enter valid email id");
            }else if(mypass == ""){
                app.Toast.show(validationMsg.logPassword());
            }else if(app.validatePassword(mypass) == false){
                app.Toast.show(validationMsg.logValidpass());
            }else if($("#zipcode_txt").val() == ""){    
                app.Toast.show(validationMsg.logZipCode());
            }else{
                var regData = {
                        "pdas_user_id":0.0,
                        "first_name":$("#first_name_txt").val(),
                        "last_name":$("#last_name_txt").val(),
                        "email_address":$("#reg_email_txt").val(),
                        "postal_area":$("#zipcode_txt").val(),
                        "postal_area_2":null,
                        "password":$("#reg_pass_txt").val(),
                        "status":null,
                        "role":null,
                        "authentication_id":$("#user_name_txt").val()
                       };
                       
                REGISTERUSER.getRegisterUser(regData);
            }
        },//validateField
        getRegisterUser: function(regData) {
            app.loaderStart("", "Please Wait....");
            var PostData = constVariable.urlMethod.get('registration');
            app.XMLHTTP.httpPostAjax(regData,"PUT",PostData, function(jsonData) {
                app.loaderStop();
                LOGIN.loginSuccess(jsonData);
               
            });
        },//getRegisterUser
        
        forgotPassword: function() {
            
            if($("#forgot_usrname_txt").val() == ""){
                app.Toast.show(validationMsg.logUserName());
                return false;
            }else if($("#forgot_email_txt").val() == ""){
                app.Toast.show(validationMsg.logEmail());
                return false;
            }else if(app.validEmail($("#forgot_email_txt").val()) == true){
                app.loaderStart("", "Please Wait....");
                var resetData = {
                        "pdas_user_id":0.0,
                        "first_name":null,
                        "last_name":null,
                        "email_address":$("#forgot_email_txt").val(),
                        "postal_area":null,
                        "postal_area_2":null,
                        "password":app.randomNumber(),
                        "status":null,
                        "role":null,
                        "authentication_id":$("#forgot_usrname_txt").val()
                       };
                var PostData = constVariable.urlMethod.get('forgot');
                app.XMLHTTP.httpPostAjax(resetData, 'POST', PostData, function(jsonData) {
                    /*ajax.responseText==>{"authentication_id":"sky","email_address":"satish@idealtechnologys.com","first_name":"satish","last_name":"yadav","password":null,"pdas_user_id":18,"postal_area":"452001","postal_area_2":null,"role":null,"status":null}*/
                    app.loaderStop();
                    app.goBack();
                    
                });
           }
        }
}//REGISTERUSER



var LOCATION = {
        localVar: {
            locationHeader: ["pdas_user_id",LOGIN.localVar.userId],
            pdasLocationId: null,
            currentLocFlage: false,
            newLat: 0,
            newLong: 0,
            prevLocationJSON: null,
            addNewLocationFlage: true,//default add location
            currentRecord: 0,
            currentAddress_components:null,
        },//localVar
        getPreLocation: function() {
            
           // app.loaderStart("", "Please Wait....");
            var PostData = constVariable.urlMethod.get('preLocation')+''+LOGIN.localVar.userId;
            app.XMLHTTP.httpPostAjax(null, 'GET', PostData, function(jsonData) {
                app.loaderStop();
                var locationList ='';
                var addNew ='';
                LOCATION.localVar.prevLocationJSON = jsonData;
                
                app.loaderStop();
                try{
                    for ( var int in jsonData) {
                        
                        addNew = jsonData[int].location_name;//+' , '+jsonData[int].line_1_address+','+jsonData[int].line_2_address+','+jsonData[int].state+' , ' +jsonData[int].postal_area;
                       
                        if(jsonData[int].line_1_address != "" || jsonData[int].line_1_address != null){
                            addNew +=', '+jsonData[int].line_1_address;
                        }
                        if(jsonData[int].line_2_address == "" || jsonData[int].line_2_address == null){}else{
                            addNew += ', '+jsonData[int].line_2_address;
                        }
                        if(jsonData[int].city != "" || jsonData[int].city != null){
                            addNew += ', '+jsonData[int].city;
                        }
                        if(jsonData[int].state != "" || jsonData[int].state != null){
                            addNew += ', '+jsonData[int].state;
                        }
                        if(jsonData[int].postal_area !== "" || jsonData[int].postal_area != null){
                            addNew += ', '+jsonData[int].postal_area;
                        }
                        
                        var allId = jsonData[int].pdas_user_id+'_'+jsonData[int].pdas_location_id;
                        locationList += '<li data-icon="true">'
                                            +'<div class="edit-del-btn-content">'
                                                +'<a href="#" class="delete-location ui-btn-icon-left ui-icon-mapicon">'
                                                    +'<img onclick="LOCATION.deleteLocation('+jsonData[int].pdas_location_id+')" alt="none" class="small_cross_icon" src="images/small_cross_icon.png" width="23px"/>'
                                                +'</a>'
                                                +'<a href="#" class="edit-location ui-btn-icon-left ui-icon-mapicon">'
                                                    +'<img onclick="LOCATION.updateLocation('+int+')" alt="none" src="images/edit_icon.png" width="23px"/>'
                                                +'</a>'
                                            +'</div>'    
                                            +'<div class="clearfix"></div>'
                                            +'<p class="font-size-blk-10">'+addNew+'</p>'
                                        +'</li>';
                       
                    }
                    app.loaderStop();
                    $( ".prev-location-listview" ).html(locationList).listview();
                    $( ".prev-location-listview" ).trigger("create");
                    $( ".prev-location-listview" ).listview( "refresh" );
                    $( ".prev-location-listview" ).trigger( "updatelayout");
                    /*var dfdf = new IScroll('.prev-location-content',{
                        scrollbars: true,
                        disableTouch: false,
                        bounceEasing: 'elastic',
                        shrinkScrollbars: 'scale',
                    });*/
                }catch (e) {
                    app.loaderStop();
                    console.log("Error"+e);
                }
            });
        },
        recordCurrentLocation: function(){
           
            if($("#location_textarea").val() == ""){
                LOCATION.getMyCurrentLocation(function(re){
                    $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#addlocation", { role: "page",transition: "slide", reverse: false  } );
                    var address_components = LOCATION.localVar.currentAddress_components;
                    var temp = '';
                    for ( var int in address_components) {
                        var addType = address_components[int].types;
                        console.log(addType.length+"addType---------->"+addType);
                        for ( var int1 in addType) {
                            if(addType[int1] == "postal_code"){
                                $("#lock_zip_txt").val(address_components[int].long_name);
                            }
                            if(addType[int1] == "sublocality_level_1"){
                                temp = address_components[int].long_name;
                                $("#lock_name_txt").val("");
                            }
                            if(addType[int1] == "route"){
                                console.log(address_components[int].long_name+"address_components[int].long_name");
                                $("#lock_street1_txt").val(address_components[int].long_name);
                            }
                            if(addType[int1] == "administrative_area_level_1"){
                                $('#drplwn_lock_state').val(address_components[int].short_name).selectmenu('refresh');
                            }
                            if(addType[int1] == "street_number"){
                                $("#lock_street2_txt").val("");
                            }
                            if(addType[int1] == "locality"){
                               $("#lock_city_txt").val(address_components[int].long_name);
                            }
                          
                        }
                    }
                });
            }else{
                $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#addlocation", { role: "page",transition: "slide", reverse: false  } );
                var address_components = LOCATION.localVar.currentAddress_components;
                var temp = '';
                for ( var int in address_components) {
                    var addType = address_components[int].types;
                    console.log(addType.length+"addType---------->"+addType);
                    for ( var int1 in addType) {
                        if(addType[int1] == "postal_code"){
                            $("#lock_zip_txt").val(address_components[int].long_name);
                        }
                        if(addType[int1] == "sublocality_level_1"){
                            temp = address_components[int].long_name;
                            $("#lock_name_txt").val("");
                        }
                        if(addType[int1] == "route"){
                            console.log(address_components[int].long_name+"address_components[int].long_name");
                            $("#lock_street1_txt").val(address_components[int].long_name);
                        }
                        if(addType[int1] == "administrative_area_level_1"){
                            $('#drplwn_lock_state').val(address_components[int].short_name).selectmenu('refresh');
                        }
                        if(addType[int1] == "street_number"){
                            $("#lock_street2_txt").val("");
                        }
                        if(addType[int1] == "locality"){
                           $("#lock_city_txt").val(address_components[int].long_name);
                        }
                      
                    }
                }
            }
        },
        getMyCurrentLocation: function(callBack) {
            
            console.log("getMyCurrentLocation");
            app.getlatitudelongitude(function(status,lat,long){
                if(status == true){
                   // app.loaderStart("", "Please Wait....");
                    console.log("lat==>"+lat+"<==>"+long); 
                    var PostData = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='+lat+','+long+'&key=AIzaSyALd1IKEp0RQ0mSyOF-UptbqwnTxw4u2mI&sensor=true';
                    app.XMLHTTP.httpPostAjax(null, 'GET', PostData, function(jsonData) {
                        app.loaderStop();
                        var addResult = jsonData.results;
                        console.log(addResult[0].formatted_address);
                        $("#location_textarea").val(addResult[0].formatted_address);
                        
                        LOCATION.localVar.currentLocFlage = true;
                        LOCATION.localVar.newLat =lat;
                        LOCATION.localVar.newLong =long;
                        LOCATION.localVar.currentAddress_components = addResult[0].address_components;
                        callBack(true);
                    });
                }else{
                    console.log("Unable to get your current location");
                    /*navigator.notification.alert(
                            'Unable to get your current location',  // message
                            function(){
                                return false;                                 
                            }, // callback
                            '',   // title
                            'Ok' // buttonName
                    );*/
                    //callBack(false);
                }
            });
            
        },//getMyCurrentLocation
        addNewLocation: function() {
            if($("#lock_name_txt").val() == ""){
                app.Toast.show(validationMsg.logLocationName());
            }else if($("#lock_street1_txt").val() == "" ){
                app.Toast.show(validationMsg.logLocationstreet());
            }else if($("#lock_city_txt").val() == "" ){
                app.Toast.show(validationMsg.logLocationcity());
            }else if($("#drplwn_lock_state option:selected").val() == "" ){
                app.Toast.show(validationMsg.logLocationstat());
            }else if($("#lock_zip_txt").val() == "" ){
                app.Toast.show(validationMsg.logZipCode());
            }else{
                if(LOCATION.localVar.addNewLocationFlage == true){//add new location 
                    
                    var newLocation = {
                            "country_code": null,
                            "latitude": LOCATION.localVar.newLat,
                            "line_1_address": $("#lock_street1_txt").val(),
                            "line_2_address": $("#lock_street2_txt").val(),
                            "city": $("#lock_city_txt").val(),
                            "location_name": $("#lock_name_txt").val(),
                            "longitude": LOCATION.localVar.newLong,
                            "pdas_location_id": 0,
                            "pdas_user_id": LOGIN.localVar.userId,
                            "postal_area": $("#lock_zip_txt").val() ,
                            "postal_area_2": null,
                            "state": $("#drplwn_lock_state option:selected").val(),
                            "status": null
                        }
                        
                        app.loaderStart("", "Please Wait....");
                        var PostData = constVariable.urlMethod.get('addlocation');
                        app.XMLHTTP.httpPostAjax(newLocation, 'PUT', PostData, function(jsonData) {
                            app.loaderStop();
                            LOCATION.localVar.addNewLocationFlage = true;
                            LOCATION.localVar.pdasLocationId = jsonData.pdas_location_id;
                            LOCATION.getPreLocation();
                            app.goBack();
                            console.log("success");
                            LOCATION.localVar.currentLocFlage = false;
                            
                        });
                    }else{                          //updateLocation
                        var updateLocation = {
                                "country_code": null,
                                "latitude": LOCATION.localVar.newLat,
                                "line_1_address": $("#lock_street1_txt").val(),
                                "line_2_address": $("#lock_street2_txt").val(),
                                "city": $("#lock_city_txt").val(),
                                "location_name": $("#lock_name_txt").val(),
                                "longitude": LOCATION.localVar.newLong,
                                "pdas_location_id": LOCATION.localVar.currentRecord.pdas_location_id,
                                "pdas_user_id": LOGIN.localVar.userId,
                                "postal_area": $("#lock_zip_txt").val() ,
                                "postal_area_2": null,
                                "state": $("#drplwn_lock_state option:selected").val(),
                                "status": null
                            }
                            
                            app.loaderStart("", "Please Wait....");
                            var PostData = constVariable.urlMethod.get('addlocation');
                            app.XMLHTTP.httpPostAjax(updateLocation, 'POST', PostData, function(jsonData) {
                                app.loaderStop();
                                LOCATION.localVar.addNewLocationFlage = true;
                                LOCATION.localVar.pdasLocationId = jsonData.pdas_location_id;
                                LOCATION.getPreLocation();
                                app.goBack();
                                console.log("success");
                                
                            });
                    }
            }
            
        },//addNewLocation
        updateLocation: function(position) {
            console.log("updateLocation position==>"+position);
            
            LOCATION.localVar.addNewLocationFlage = false;
            
            $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#addlocation", { role: "page",transition: "slide", reverse: false  } );
            //LOCATION.localVar.prevLocationJSON[position];
            $("#lock_name_txt").val(LOCATION.localVar.prevLocationJSON[position].location_name);
            $("#lock_street1_txt").val(LOCATION.localVar.prevLocationJSON[position].line_1_address);
            $("#lock_street2_txt").val(LOCATION.localVar.prevLocationJSON[position].line_2_address);
            $("#lock_city_txt").val(LOCATION.localVar.prevLocationJSON[position].city);
            
            document.getElementById("drplwn_lock_state").value = LOCATION.localVar.prevLocationJSON[position].state;
            $('#drplwn_lock_state').val(LOCATION.localVar.prevLocationJSON[position].state).selectmenu('refresh');
            //$("#drplwn_lock_state").val(LOCATION.localVar.prevLocationJSON[position].state);
            $("#lock_zip_txt").val(LOCATION.localVar.prevLocationJSON[position].postal_area);
            LOCATION.localVar.currentRecord = LOCATION.localVar.prevLocationJSON[position]; 
        },
        deleteLocation: function(locationId) {
            console.log("deleteLocation locationId==>"+locationId);
            navigator.notification.confirm(
                    'Are you sure want to delete',  // message
                    function(button){
                        if(button == 1){
                            app.loaderStart("", "Please Wait....");
                            var PostData = constVariable.urlMethod.get('delLocation')+''+locationId;
                            app.XMLHTTP.httpPostAjax(null, 'DELETE', PostData, function(jsonData) {
                                app.loaderStop();
                                console.log("success");
                                app.loaderStop();
                                
                                LOCATION.getPreLocation();
                            });
                        }
                            
                    },              // callback to invoke with index of button pressed
                    '',            // title
                    'Yes,No'          // buttonLabels
            );
            
        },
        getStateList: function() {
            var obj=document.getElementById("drplwn_lock_state");  
            console.log("getStateList obj.length==>"+obj.length);
            if(obj.length != 0)
                return true;
            
            app.loaderStart("", "Please Wait...");
            var codeData = constVariable.urlMethod.get('codesRole')+'state';
            app.XMLHTTP.httpPostAjax(null, 'GET', codeData, function(jsonData) {
              
                app.loaderStop();
               
                while(obj.length != 0){
                    obj.remove(0);
                    $('#drplwn_lock_state').val("").selectmenu('refresh');
                    }
                $('#drplwn_lock_state').append('<option value="" selected="selected">State</option>');
                 for (var int = 0; int < jsonData.length; int++) {
                        opt = document.createElement("option");
                        opt.value = jsonData[int].code;
                        opt.text = jsonData[int].description;
                        obj.appendChild(opt);
                       /* opt.id = jsonData[int].CountryId*/
                    }
                     app.loaderStop();
                     $('#drplwn_lock_state').selectmenu();
                     $('#drplwn_lock_state').val("").selectmenu('refresh');
            });
        },
}//LOCATION




var PREFERENCE = {
        localVar: {
            manufacturePageId: 1,
            drugPageId: 1,
            selected_drugObj: null,//for drug field
            selectedManufactureId: 0,
            productSearchPagedWebSearchText: '',//if more then 10 recards
            manufactureSearchPagedWebSearchText: '',//if more then 10 recards
            addEditFlage: null,// set default null for add
            
        },//localVar
        getUserDetails: function() {                        //user PREFERENCE
            app.loaderStart("", "Please Wait....");
            var PostData = constVariable.urlMethod.get('userDetails')+''+LOGIN.localVar.userId;
            app.XMLHTTP.httpPostAjax(null,'GET',PostData,function(jsonData){
                app.loaderStop();
                $("#pre_first_name_txt").val(jsonData.first_name);
                $("#pre_last_name_txt").val(jsonData.last_name);
                $("#pre_email_txt").val(jsonData.email_address);
                $("#pre_pass_txt").val(LOGIN.localVar.password);
                $("#pre_zipcode_txt").val(jsonData.postal_area);
            });
            
        },//getUserDetails
        updateUserDetails: function(event) {
            var mypass = $("#pre_pass_txt").val();
            if($("#pre_first_name_txt").val() == ""){
                app.Toast.show(validationMsg.logUserName());
            }else if($("#pre_last_name_txt").val() == ""){
                app.Toast.show(validationMsg.logLastName());
            }else if($("#pre_email_txt").val() == ""){
                app.Toast.show(validationMsg.logEmail());
            }else if(app.validEmail($("#pre_email_txt").val()) == false){
                
            }else if(mypass == ""){
                app.Toast.show(validationMsg.logPassword());
            }else if(app.validatePassword(mypass) == false){
                app.Toast.show(validationMsg.logValidpass());
            }else if($("#pre_zipcode_txt").val() == ""){    
                app.Toast.show(validationMsg.logZipCode());
            }else{
                var updateData = {
                        "pdas_user_id":LOGIN.localVar.userId,
                        "first_name":$("#pre_first_name_txt").val(),
                        "last_name":$("#pre_last_name_txt").val(),
                        "email_address":$("#pre_email_txt").val(),
                        "postal_area":$("#pre_zipcode_txt").val(),
                        "postal_area_2":null,
                        "password":$("#pre_pass_txt").val(),
                        "status":null,
                        "role":null,
                        "authentication_id":LOGIN.localVar.authId
                       };
                app.loaderStart("", "Please Wait....");
                var PostData = constVariable.urlMethod.get('registration');
                app.XMLHTTP.httpPostAjax(updateData,'POST',PostData,function(jsonData){
                    app.loaderStop();
                    console.log("update user details");
                });
            }
            
        },//updateUserDetails end user PREFERENCE
       
        UserDrugPreference:{// DRUG PREFERENCE
            prev_position: null,
            prev_ele: null,
            getManufactureList: function(event,ele) {//First text field
                PREFERENCE.localVar.selectedManufactureId = event;
                console.log("getManufactureList==>"+$(ele).text()+"manufactId==>"+event);
                $("#add_manufacture_name_txt").val($(ele).text());
                $("#autocomplete").html("");
                $("#autocomplete").height(0);
                $( "#autocomplete" ).filterable( "refresh" );
                
                if($("#add_drug_name_txt").val() != ""){
                    $('#drplwn_manufacture').val("").selectmenu('refresh');
                    $( "#drplwn_manufacture" ).addClass("ui-state-disabled");
                    $( "#drplwn_manufacture" ).attr( "disabled", "disabled" );
                    
                    var PostData = constVariable.urlMethod.get('productSearch')+'query='+$("#add_drug_name_txt").val()+'&ManufacturerId='+PREFERENCE.localVar.selectedManufactureId+'&page='+PREFERENCE.localVar.drugPageId;
                    app.XMLHTTP.httpPostAjax(null, "GET", PostData, function(jsonData) {
                        app.loaderStop();
                        PREFERENCE.localVar.selected_drugObj = jsonData;
                        
                        if(jsonData.length == 10)
                            PREFERENCE.localVar.productSearchPagedWebSearchText = $input.val();
                         
                        PREFERENCE.UserDrugPreference.getDrugsList(PREFERENCE.UserDrugPreference.prev_position,PREFERENCE.UserDrugPreference.prev_ele);
                    }) 
                }
                
            },
            getDrugsList: function(positon,ele) {//search by name drug or product list second drug field
                console.log("getDrugsList==>"+$(ele).text());
                PREFERENCE.UserDrugPreference.prev_position = positon;
                PREFERENCE.UserDrugPreference.prev_ele = ele;
                
                var drugObj=PREFERENCE.localVar.selected_drugObj[positon];
                
                PREFERENCE.localVar.selected_drugObj = drugObj;
                
                
                $("#add_drug_name_txt").val($(ele).text());
                $("#drugautocomplete").html("");
                $("#drugautocomplete").height(0);
                $( "#drugautocomplete" ).filterable( "refresh" );
                
                $("#autocomplete").html("");
                $("#autocomplete").height(0);
                $( "#autocomplete" ).filterable( "refresh" );
                
                $( "#drplwn_drivetrain" ).removeClass("ui-state-disabled");
                $( "#drplwn_drivetrain" ).attr( "disabled", "" );
                /*$( "#drplwn_manufacture" ).removeClass("ui-state-disabled");
                $( "#drplwn_manufacture" ).attr( "disabled", "" );*/
                
                
                
                $( "#drplwn_drivetrain" ).selectmenu( "enable" );
                $('#drplwn_drivetrain').val("").selectmenu('refresh');
                
                
                /*$( "#drplwn_manufacture" ).selectmenu( "enable" );
                $('#drplwn_manufacture').val("").selectmenu('refresh');*/
                
                if($("#add_manufacture_name_txt").val() == ""){
                    var manufacturerArr = drugObj.Manufacturer;
                    console.log(manufacturerArr+"manufacturerArr  --------->"+manufacturerArr.length);
                    
                    var html='';
                    for ( var manuf in manufacturerArr) {
                        html += '<li onclick="PREFERENCE.UserDrugPreference.getManufactureList('+manufacturerArr[manuf].pdas_manufacturer_id+',this)">' + manufacturerArr[manuf].manufacturer_name + '</li>';
                    }
                    
                    $("#autocomplete").html( html );
                    if(manufacturerArr.length > 0)
                        $("#autocomplete").height((app.getDeviceHeight()*35)/100);
                    else
                        $("#autocomplete").height(0);
                    
                    $("#autocomplete").css("overflow","scroll");
                    $("#autocomplete").listview( "refresh" );
                    $("#autocomplete").trigger( "updatelayout");
                }
                //$("#add_manufacture_name_txt").val(drugObj.manufacturer_name);
                try{
                
                    var obj=document.getElementById("drplwn_drivetrain"); 
                    while(obj.length != 0){
                        obj.remove(0);
                        }
                    $('#drplwn_drivetrain').append('<option value="" selected="selected">Strength</option>');
                    $('#drplwn_drivetrain').val("").selectmenu('refresh');
                    var  opt='';
                    var ProductNDC = drugObj.ProductNDC;
                    for ( var int1 in ProductNDC) {
                        var drugIngredients = ProductNDC[int1].Ingredients;
                        var strength_str='';
                        for (var int = 0; int < drugIngredients.length; int++)     {
                            strength_str += ''+drugIngredients[int].ingredient_name+' '+drugIngredients[int].ingredient_strength;
                            if(drugIngredients.length == (int+1)){
                                opt = document.createElement("option");
                                opt.value = drugObj.md_user_display_id+'_'+drugIngredients[int].md_ingredient_id;
                                opt.text = strength_str;
                                obj.appendChild(opt);
                                /*opt.id = drugIngredients[int].pdas_product_ndc_id;*/
                            }
                            
                        }
                    }
                    $('#drplwn_drivetrain').selectmenu();
                    $('#drplwn_drivetrain').val("").selectmenu('refresh');
                }catch (e) {
                    console.log("error"+e);
                }         
                app.loaderStop();
            },
            
            getPreviousDrugPreference: function() { // get the list of all previous added preference
                app.loaderStart("", "Please Wait....");
                var PostData = constVariable.urlMethod.get('previousDrugList')+''+LOGIN.localVar.userId;
                app.XMLHTTP.httpPostAjax(null,'GET',PostData,function(jsonData){
                    app.loaderStop();
                    console.log("getPreviousDrugPreference success");
                    
                    var content='';
                    
                    if(jsonData.length == 0)
                        content = '<li data-icon="false" class="no-record-found">No Records Found.</li>';
                    
                    for ( var int in jsonData) {
                        var productDetail = jsonData[int].ProductDetail;
                        var productNDC = productDetail.ProductNDC;
                        
                        var pdas_manufacturerName='';
                        var pdas_manufacturerId = jsonData[int].pdas_manufacturer_id;
                        var manufacturer = productDetail.Manufacturer;
                        for ( var xy in manufacturer) {
                            console.log(manufacturer[xy].pdas_manufacturer_id +"  ==  "+ pdas_manufacturerId);
                            if(manufacturer[xy].pdas_manufacturer_id == pdas_manufacturerId){
                                pdas_manufacturerName = manufacturer[xy].manufacturer_name;
                                break;
                            }

                        }
                        console.log("  ="+pdas_manufacturerName+"=  "+ pdas_manufacturerId);
                        
                        var md_ingredientId = jsonData[int].md_ingredient_id;
                        var md_ingredientName='';
                        
                        
                        for ( var z in productNDC) {
                            var ingredients = productNDC[z].Ingredients;
                            for ( var t in ingredients) {
                                if(ingredients[t].md_ingredient_id == md_ingredientId){
                                    md_ingredientName += ingredients[t].ingredient_name+' '+ingredients[t].ingredient_strength;
                                }
                            }
                            
                        }
                        var routeDescription = jsonData[int].route_description
                        if(routeDescription == null)
                            routeDescription='';
                        
                        
                        content += '<li>'
                                    +'<div class="edit-auto-pre-btn">' 
                                    +'<img alt="none" onclick="PREFERENCE.UserDrugPreference.editDrugPreference('+jsonData[int].pdas_user_drug_preference_id+')" src="images/edit_img.png"/>'     
                                    +'</div>'
                                    +'<p style="white-space: pre-wrap; min-height: 16px;"><span>'+productDetail.md_user_display+'</span></p>'
                                    +'<p style="white-space: pre-wrap; min-height: 16px;"><span>'+pdas_manufacturerName+'</span></p>'
                                    +'<p style="white-space: pre-wrap; min-height: 16px;"><span>'+routeDescription+'</span></p>'
                                   // +'<p style="white-space: pre-wrap; min-height: 16px;"><span>'+md_ingredientName+'</span></p>'
                                    +'<div class="delete-auto-pre-btn">'
                                        +'<img onclick="PREFERENCE.UserDrugPreference.deleteDrugPreference('+jsonData[int].pdas_user_drug_preference_id+')" alt="none" src="images/delete_divider.png"/>'       
                                    +'</div>'
                                 +'</li>';
                    }
                    $( "#drug_preference_listview" ).html(content).listview();
                    $( "#drug_preference_listview" ).trigger("create");
                    $( "#drug_preference_listview" ).listview( "refresh" );
                    $( "#drug_preference_listview" ).trigger( "updatelayout");
                    
                });
            },//getPreviousDrugPreference
            
            
            deleteDrugPreference: function(delId) { // Delete drug preference by id
                console.log("deleteDrugPreference delId==>"+delId);
                navigator.notification.confirm(
                        'Are you sure want to delete',  // message
                        function(button){
                            if(button == 1){
                                try{
                                    app.loaderStart("", "Please Wait....");
                                    var PostData = constVariable.urlMethod.get('delDrugList')+''+delId;
                                    app.XMLHTTP.httpPostAjax(null,'DELETE',PostData,function(jsonData){
                                        console.log("deleteDrugPreference success==>");
                                        app.loaderStop();
                                        PREFERENCE.UserDrugPreference.getPreviousDrugPreference();
                                    });
                                }catch (e) {
                                    console.log("Error == >"+e);
                                }
                            }
                                
                        },              // callback to invoke with index of button pressed
                        '',            // title
                        'Yes,No'          // buttonLabels
                );
                
                
            },//deleteDrugPreference
            
            
            
            addDrugPreference: function() {
                var webMethod = 'PUT'; //defalult for add
                var drugParam = new Object();
                
                if(PREFERENCE.localVar.addEditFlage != null){
                    webMethod = 'POST';
                    drugParam.pdas_user_drug_preference_id = PREFERENCE.localVar.addEditFlage;
                }
                console.log("PREFERENCE.localVar.addEditFlage=====>"+PREFERENCE.localVar.addEditFlage);
                /*if($("#add_manufacture_name_txt").val() == ""){
                    app.Toast.show(validationMsg.logDrugManufactureName());
                }else */
                if($("#add_drug_name_txt").val() == ""){
                    app.Toast.show(validationMsg.logDrugName());
                }else if($("#drplwn_drivetrain option:selected").val() == ""){
                    app.Toast.show(validationMsg.logDrugStrength());
                }/*else if($("#drplwn_manufacture option:selected").val() == ""){
                    app.Toast.show(validationMsg.logDrugRoute());
                }*/else{
                    
                    if(PREFERENCE.localVar.selectedManufactureId == "")
                        PREFERENCE.localVar.selectedManufactureId = 0;
                        
                    var routeCode = '';
                    var ingrTemp = $("#drplwn_drivetrain option:selected").val();
                    var newVal = ingrTemp.split("_");
                    routeCode = $("#drplwn_manufacture option:selected").val();
                    
                    drugParam.pdas_user_id = LOGIN.localVar.userId;;
                    drugParam.pdas_manufacturer_id  = PREFERENCE.localVar.selectedManufactureId; 
                    drugParam.md_product_id =  newVal[0];   
                    drugParam.md_ingredient_id = newVal[1];
                    drugParam.route_code  = routeCode;
                    
                    app.loaderStart("", "Please Wait....");
                    var PostData = constVariable.urlMethod.get('addDrugPreference');
                    app.XMLHTTP.httpPostAjax(drugParam,webMethod,PostData,function(jsonData){
                        console.log("addDrugPreference ==>");
                        app.loaderStop();
                        app.goBack();
                        PREFERENCE.localVar.addEditFlage = null; //set default record
                        PREFERENCE.localVar.selectedManufactureId =0;
                        $("#add_manufacture_name_txt").val("");
                        $("#add_drug_name_txt").val("");
                        var obj1=document.getElementById("drplwn_manufacture"); 
                        var obj=document.getElementById("drplwn_drivetrain"); 
                        while(obj.length != 0){
                            obj.remove(0);
                            }
                        while(obj1.length != 0){
                            obj1.remove(0);
                            }
                        $('#drplwn_manufacture').append('<option value="" selected="selected">Route</option>');
                        $('#drplwn_manufacture').val("").selectmenu('refresh');
                        
                        $('#drplwn_drivetrain').append('<option value="" selected="selected">Strength</option>');
                        $('#drplwn_drivetrain').val("").selectmenu('refresh');
                        
                        PREFERENCE.UserDrugPreference.getPreviousDrugPreference();
                    });
                }
            },//addDrugPreference
            
            editDrugPreference: function(prefId) {
                $(".addAutoPreferences_lbl").text("Edit Drug");
                $("#addauto_preferences_btn").text("Update");
                
                $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#addAutoPreferences", { role: "page",transition: "slide", reverse: false  } );
                app.loaderStart("", "Please Wait....");
                var PostData = constVariable.urlMethod.get('delDrugList')+''+prefId;
                app.XMLHTTP.httpPostAjax(null,'GET',PostData,function(jsonData){
                    app.loaderStop();

                    PREFERENCE.localVar.addEditFlage = prefId; //for edit record
                    PREFERENCE.localVar.selected_drugObj = jsonData.ProductDetail;

                    var drugObj = jsonData.ProductDetail;    
                    var pdasManufacturer_id = jsonData.pdas_manufacturer_id;
                    var mdIngredient_id = jsonData.md_ingredient_id;
                    var mdUser_display_id = drugObj.md_user_display_id;
                    PREFERENCE.localVar.selectedManufactureId = pdasManufacturer_id;

                    $("#add_drug_name_txt").val(drugObj.md_user_display);
                    $("#drugautocomplete").html("");
                    $("#drugautocomplete").height(0);
                    $( "#drugautocomplete" ).filterable( "refresh" );

                    $("#autocomplete").html("");
                    $("#autocomplete").height(0);
                    $( "#autocomplete" ).filterable( "refresh" );

                    $( "#drplwn_drivetrain" ).removeClass("ui-state-disabled");
                    $( "#drplwn_drivetrain" ).attr( "disabled", "" );
                    $( "#drplwn_drivetrain" ).selectmenu( "enable" );
                    $('#drplwn_drivetrain').val("").selectmenu('refresh');


                    $( "#drplwn_manufacture" ).selectmenu( "enable" );
                    $('#drplwn_manufacture').val("").selectmenu('refresh')
                    var manufacturerArr = drugObj.Manufacturer;
                    if(pdasManufacturer_id == 0){
                        $("#add_manufacture_name_txt").val("");
                        $("#autocomplete").height(0);
                        $("#autocomplete").listview( "refresh" );
                        $("#autocomplete").trigger( "updatelayout");
                    }else{
                        for ( var int12 in manufacturerArr) {
                            if(manufacturerArr[int12].pdas_manufacturer_id == pdasManufacturer_id){
                                $("#add_manufacture_name_txt").val(manufacturerArr[int12].manufacturer_name);
                                $("#autocomplete").height(0);
                                $("#autocomplete").listview( "refresh" );
                                $("#autocomplete").trigger( "updatelayout");
                                break;
                            }
                        }
                    }

                    try{

                        var obj=document.getElementById("drplwn_drivetrain"); 
                        while(obj.length != 0){
                            obj.remove(0);
                        }

                        var  opt='';
                        var ProductNDC = drugObj.ProductNDC;
                        for ( var int1 in ProductNDC) {

                            var drugIngredients = ProductNDC[int1].Ingredients;
                            var strength_str='';
                            for (var int5 = 0; int5 < drugIngredients.length; int5++){
                                strength_str += ''+drugIngredients[int5].ingredient_name+' '+drugIngredients[int5].ingredient_strength;
                                if(drugIngredients.length == (int5+1)){
                                    opt = document.createElement("option");
                                    opt.value = drugObj.md_user_display_id+'_'+drugIngredients[int5].md_ingredient_id;
                                    opt.text = strength_str;
                                    obj.appendChild(opt);
                                    /*opt.id = drugIngredients[int].pdas_product_ndc_id;*/
                                }

                            }
                            $('#drplwn_drivetrain').val(mdUser_display_id+"_"+mdIngredient_id).selectmenu('refresh');

                            var tempRoute = ProductNDC[int1].Route;
                            var objR=document.getElementById("drplwn_manufacture"); 
                            while(objR.length != 0){
                                objR.remove(0);
                            }
                            for (var int8 = 0; int8 < tempRoute.length; int8++) {
                                opt1 = document.createElement("option");
                                opt1.value = tempRoute[int8].route_code;
                                opt1.text = tempRoute[int8].description;
                                objR.appendChild(opt1);
                                /* opt.id = jsonData[int].CountryId*/
                            } 

                        }
                        console.log("mdIngredient_id---->"+mdIngredient_id+"====route_code=="+jsonData.route_code);
                        if(jsonData.route_description != null){
                            $('#drplwn_manufacture').val(jsonData.route_code).selectmenu('refresh');
                        }else{
                            //$('#drplwn_manufacture').append('<option value="" selected="selected">Route</option>');
                            $('#drplwn_manufacture').val("").selectmenu('refresh');
                        }

                    }catch (e) {
                        console.log("error"+e);
                    }         

                });

            },//editDrugPreference
        
        },//UserDrugPreference
        
        
        
}//PREFERENCE



var HOME = {
      localVar: {
          recallPageCount: 1,
          warningPageCount: 1,
          sentiPageCount: 1,
          recallPageWebService:'',
          warningPageWebService:'',
      },//localVar
      
      /*  i.  Value = -1 : Display Red traffic light
          ii. Value = 0: Orange traffic light.
          iii.Value  = 1: Green traffic light.
       */
      
      homeInit: function() {
          app.loaderStart("", "Please Wait....");
          var PostData = constVariable.urlMethod.get('previousDrugList')+''+LOGIN.localVar.userId;
          app.XMLHTTP.httpPostAjax(null,'GET',PostData,function(jsonData){
              console.log("success home");
              var content_Html = '';
             
              for ( var int in jsonData) {
                  var temp='';
                  var recallStatus = jsonData[int].pdas_product_recall_status;
                  var warningStatus = jsonData[int].pdas_product_warning_status;
                  var sentimentStatus = jsonData[int].pdas_product_sentiment_status;
                  var drug_preference_id = jsonData[int].pdas_user_drug_preference_id;
                  var productDetail = jsonData[int].ProductDetail;
                
                  var myProduct_sentiment_rate = jsonData[int].md_aggregated_sentiment;  
                  
                  var md_ingredientId = jsonData[int].md_ingredient_id;
                  var md_ingredientName='';
                  
                  productNDC = productDetail.ProductNDC;
                  for ( var z in productNDC) {
                      var ingredients = productNDC[z].Ingredients;
                      for ( var t in ingredients) {
                          if(ingredients[t].md_ingredient_id == md_ingredientId){
                              md_ingredientName += ingredients[t].ingredient_name+' '+ingredients[t].ingredient_strength;
                          }
                      }
                      
                  }
                  
                  var pdas_manufacturerName='';
                  var pdas_manufacturerId = jsonData[int].pdas_manufacturer_id;
                  var manufacturer = productDetail.Manufacturer;
                  for ( var xy in manufacturer) {
                      console.log(manufacturer[xy].pdas_manufacturer_id +"  ==  "+ pdas_manufacturerId);
                      if(manufacturer[xy].pdas_manufacturer_id == pdas_manufacturerId){
                          pdas_manufacturerName = manufacturer[xy].manufacturer_name;
                          break;
                      }

                  }
                  
                  console.log("recallStatus"+recallStatus+"<=recallStatus img ->"+HOME.getImgStatus(recallStatus));
                  var routeDescription = jsonData[int].route_description
                  if(routeDescription == null)
                      routeDescription='';
                  var rateClass= 'rating';
                  if(myProduct_sentiment_rate == 0)
                      rateClass= 'rating';
                  else
                      rateClass= 'rating-fix';
                  
                  
                  content_Html += '<li class="home-list">'
                               +'<div class="home-status">'
                               +'<p><strong>Drug Name: </strong>'+productDetail.md_user_display+'</p>'
                               +'<p><strong>Manufacturer Name: </strong>'+pdas_manufacturerName+'</p>'
                               +'<p><strong>Strength: </strong>'+md_ingredientName+'</p>'
                               +'<p><strong>Route of Administration: </strong>'+routeDescription+'</p>'
                               +'<div class="'+rateClass+'" data-value="'+drug_preference_id+'" data-score="'+myProduct_sentiment_rate+'"></div>'
                               +'</div>'
                               +'<div class="home-status-btn">'
                               +'<div class="oreng-status-c">'
                               +'<p class="home-status-lbl-p">Recall</p>'
                               +'<div class="oreng-status">'
                               +'<img class="homeRecall" alt="'+drug_preference_id+'" src="'+HOME.getImgStatus(recallStatus)+'"/>'
                               +'</div>'
                               +'</div>'
                               +'<div class="red-status-c">'
                               +'<p class="home-status-lbl-p">Warning</p>'
                               +'<div class="red-status">'
                               +'<img class="homeWarning" alt="'+drug_preference_id+'" src="'+HOME.getImgStatus(warningStatus)+'" />'
                               +'</div>'
                               +'</div>'
                               /*+'<div class="green-status">'
                               +'<p class="home-status-lbl-p">Sentiment</p>'
                               +'<img class="homeSentiment" alt="'+drug_preference_id+'" src="'+HOME.getImgStatus(sentimentStatus)+'"/>'
                               +'</div>'*/
                               +'</div>'
                               +'</li><!-- /li -->';
                  
                  
              }
              
              $("#home_menu_listview").html(content_Html).listview();
              $( "#home_menu_listview" ).trigger("create");
              $( "#home_menu_listview" ).listview( "refresh" );
              $( "#home_menu_listview" ).trigger( "updatelayout");
               
              $( ".homeRecall" ).on( "tap", HOME.homeRecall );
              $( ".homeWarning" ).on( "tap", HOME.homeWarning );
              //$( ".homeSentiment" ).on( "tap", HOME.homeSentiment );
              
              $('.rating').raty({
                  numberMax : 5,
                  starOff : 'images/star-off.png',
                  starOn  : 'images/star-on.png',
                  click: function(score, evt) {
                      LOGIN.localVar.ratingElement = this;
                      HOME.localVar.drugPreference_id = $(this).attr('data-value');
                      $( "#popup-outside-page" ).popup( "open" );
                      $("#rating_description").val("");
                      //$(this).raty('reload');
                      $("#numberMax").raty('reload');
                      console.log('ID: ' + this.id + "\nscore: " + score + "\nevent: " + evt);
                      return false;
                    }
                });
              
              $('.rating-fix').raty({
                  readOnly: true,
                  starOff : 'images/star-off.png',
                  starOn  : 'images/star-on.png',
                  score: function() {
                    console.log("$(this).attr('data-score') "+$(this).attr('data-score'));
                    return $(this).attr('data-score');
                  }
                });
          });
      },
      getImgStatus: function(key) {
          switch (key) {
                case -1: return 'images/red_circle.png';
                    break;
                case 0: return 'images/yellow_circle.png';
                    break;
                case 1: return 'images/green_circle.png';
                    break;
                default: return 'images/green_circle.png';
                    break;
          }
      },
      homeRecall: function(event) {
          HOME.localVar.recallPageCount = 1;
          console.log("homeRecall==>"+event.target.alt);
          $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#recall", { role: "page",transition: "slide", reverse: false  } );
          
          app.loaderStart("", "Please Wait....");
          var PostData = constVariable.urlMethod.get('recallList')+''+event.target.alt+'&Page='+HOME.localVar.recallPageCount;
          app.XMLHTTP.httpPostAjax(null,'GET',PostData,function(jsonData){
              $("#setrecoll").html("");
              
              if(jsonData.length == 10){
                  HOME.localVar.recallPageWebService = constVariable.urlMethod.get('recallList')+''+event.target.alt+'&Page=';
                  HOME.localVar.recallPageCount= 2;
              }
              
              for ( var int in jsonData) {
                  var recallDetails = jsonData[int].RecallDetails;
                  console.log("recallDetails==> "+recallDetails.length);
                  var temp_recall='';
                  for(var int1 in recallDetails){
                      
                      var dtValue = recallDetails[int1].recall_date;
                      var dtString="";
                      if (dtValue.substring(0, 6) == "/Date("){
                         var dt = new Date(parseInt(dtValue.substring(6, dtValue.length - 2)));
                         dtString = (dt.getMonth() + 1) + "/" + dt.getDate() + "/" + dt.getFullYear();
                       }
                      
                      temp_recall += '<p><strong>Date of Recall:</strong>'+dtString+'</p>'
                                  +'<p><strong>Description:</strong>'+recallDetails[int1].recall_description+'</p>';
                      
                  }
                  var content = '<div data-role="collapsible" class="grey-border" data-collapsed="true" data-collapsed-icon="carat-r"  data-expanded-icon="carat-d">'
                      +'<h3>'+jsonData[int].manufacturer_name+'</h3>'
                      +temp_recall
                      +'</div>';
                 $( "#setrecoll" ).append( content ).collapsibleset( "refresh" );
              }
              $("#setrecoll").children(":first").collapsible( "expand" );
             /* if(jsonData.length >= 10){
                  var nextPrev ='<div class="next-prev-btns">'
                      +'<a href="#" id="nextRecall" class="ui-btn next-page">Next</a>'
                      +'<a href="#" id="prevRecall" class="ui-btn prev-page">Prev</a>'
                      +'</div>';
                  $( "#setwarning" ).append( nextPrev ).collapsibleset( "refresh" );
              }*/
          });
        
      },//homeRecall
      
      homeWarning: function(event) {
          HOME.localVar.recallPageCount = 1;
          console.log("homeWarning==>"+event.target.alt);
          $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#warning", { role: "page",transition: "slide", reverse: false  } );
          
          app.loaderStart("", "Please Wait....");
          var PostData = constVariable.urlMethod.get('warningList')+''+event.target.alt+'&Page='+HOME.localVar.warningPageCount;
          app.XMLHTTP.httpPostAjax(null,'GET',PostData,function(jsonData){
              $("#setwarning").html("");
              
              if(jsonData.length == 10){
                  HOME.localVar.warningPageWebService = constVariable.urlMethod.get('warningList')+''+event.target.alt+'&Page=';
                  HOME.localVar.warningPageCount = 2;
              }
              
              for ( var int in jsonData) {
                  var warningDetails= jsonData[int].WarningDetails;
                  console.log("warningDetails==> "+warningDetails.length);
                  var temp_warning= '';
                  for ( var int1 in warningDetails) {
                      
                      var dtValue = warningDetails[int1].warning_date;
                      var dtString="";
                      if (dtValue.substring(0, 6) == "/Date("){
                         var dt = new Date(parseInt(dtValue.substring(6, dtValue.length - 2)));
                         dtString = (dt.getMonth() + 1) + "/" + dt.getDate() + "/" + dt.getFullYear();
                       }
                      
                      temp_warning += '<p><strong>Date of Warning: </strong> ' + dtString + '</p>'
                                   +'<p><strong>Description: </strong> ' + warningDetails[int1].warning_description + ' </p>';
                   
                  }
                  var content = '<div data-role="collapsible" class="grey-border" data-collapsed="true" data-collapsed-icon="carat-r"  data-expanded-icon="carat-d">'
                      +'<h3>'+jsonData[int].manufacturer_name+'</h3>'
                      +temp_warning
                      +'</div>';
                  $( "#setwarning" ).append( content ).collapsibleset( "refresh" );
              }
              
              $("#setwarning").children(":first").collapsible( "expand" );
              /*if(jsonData.length >= 10){
                  var nextPrev ='<div class="next-prev-btns">'
                      +'<a href="#" id="nextWarning" class="ui-btn next-page">Next</a>'
                      +'<a href="#" id="prevWarning" class="ui-btn prev-page">Prev</a>'
                      +'</div>';
                  $( "#setwarning" ).append( nextPrev ).collapsibleset( "refresh" );
              }*/
              
          });
          
      },//homeWarning
      homeSentiment: function(event) {
          console.log("homeSentiment==>"+event.target.alt);
          $( ":mobile-pagecontainer" ).pagecontainer( "change", "index.html#sentiment", { role: "page",transition: "slide", reverse: false  } );
          //var htmlCotent='';
          /*app.loaderStart("", "Please Wait....");
          var PostData = constVariable.urlMethod.get('sentimentList');
          app.XMLHTTP.httpPostAjax(null,'GET',PostData,function(jsonData){
              
          });*/
          
          
          
      },//homeSentiment
      sentimentRating: function(ele) {
          var myRate = new Object();
          
          if(LOGIN.localVar.ratingCount == 0){
              app.Toast.show(validationMsg.logRate());
          }else{
              console.log('$("#rating_description").val()====>'+$("#rating_description").val());
              
              myRate.ProductDetail= null;
              myRate.description = $("#rating_description").val();
              myRate.md_aggregated_sentiment = 0;
              myRate.pdas_user_drug_preference_id = HOME.localVar.drugPreference_id;
              myRate.sentiment= LOGIN.localVar.ratingCount;
              myRate.pdas_user_product_sentiment_id = 0;
              myRate.status = "ACTV";
              
// {"ProductDetail":null,"description":"A test Sentiment","md_aggregated_sentiment":0,"pdas_user_drug_preference_id":50,"pdas_user_product_sentiment_id":6,"sentiment":2,"status":"ACTV"}
              
              var rateCount =  LOGIN.localVar.ratingCount;
              
              console.log(" LOGIN.localVar.ratingCount"+ rateCount);
              $(LOGIN.localVar.ratingElement).raty('click', LOGIN.localVar.ratingCount);
              $(LOGIN.localVar.ratingElement).raty('readOnly', true);
            
              $( "#popup-outside-page" ).popup( "close" );
              LOGIN.localVar.ratingCount = 0;
              app.loaderStart("", "Please Wait....");
              var PostData = constVariable.urlMethod.get('sentimentRate');
              app.XMLHTTP.httpPostAjax(myRate,'PUT',PostData,function(jsonData){
                  app.loaderStop();
                  LOGIN.localVar.ratingCount = 0;
                  $("#rating_description").val("");
                  $('#numberMax').raty('reload');
                  /*{
                      "description": "A test Sentiment",
                      "pdas_user_drug_preference_id": 50,
                      "pdas_user_product_sentiment_id": 4,
                      "sentiment": 2,
                      "status": "ACTV"
                  }*/
                  
             });
          }
      },
      
      
   }//HOME


