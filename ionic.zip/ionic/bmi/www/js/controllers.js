angular.module('starter.controllers', [])


.controller('HeightCtrl', function($scope,$state) {
    
    
   $scope.saveHeight =  function() {
       $state.go('weight');
   }
   $scope.feet = [
                    {name:'0', value:'0'},
                    {name:'1', value:'1'},
                    {name:'2', value:'2'},
                    {name:'3', value:'3'},
                    {name:'4', value:'4'},
                    {name:'5', value:'5'},
                    {name:'6', value:'6'},
                    {name:'7', value:'7'},
                    {name:'8', value:'8'},
                    {name:'9', value:'9'},
                    {name:'10', value:'10'}
                  ];
   $scope.myHeightFeet = $scope.feet[0]; // red
   $scope.myHeightInch = $scope.feet[0]; // red              
    
   $scope.getMyHeightFeet = function(selectedWeight){
       console.log(selectedWeight.value);
   }
   $scope.getMyHeightInch = function(selectedWeight){
       console.log(selectedWeight.value);
   }   
   
})
.controller('WeightCtrl', function($scope,$state) {
     $scope.body = {
            weight: null,
            waist: null
          };
    
    $scope.genderChange = function(gender) {// false = MALE and true FEMALE
        if(gender === true)
            gender = 'F';
        else
            gender = 'M';
        console.log('gender Change', gender);
    };
    $scope.wieghtUnitChange = function(unit) {//false = LBS and True = KGS
        if(unit === true)
            unit = 'KGS';
        else
            unit = 'LBS';
        
        console.log('unit Change', unit);
    };
    $scope.saveWeight = function(body) {
       if(body.weight === null || body.waist === null)
           return false;
        
        console.log(body.weight);
        console.log(body.waist);
        $state.go('bmi-details');
        
   }
    
    
    
})
.controller('BmiDetailsCtrl', function($scope,$state) {
   $scope.RegisterUser = function(){
       $state.go('tab.dash');
   }
})

.controller('DashCtrl', function($scope,$filter) {
    
      
})

.controller('ChatsCtrl', function($scope, Chats) {
  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  }
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
 // $scope.chat = Chats.get($stateParams.chatId);
})

.controller('FriendsCtrl', function($scope, Friends) {
  $scope.friends = Friends.all();
})

.controller('FriendDetailCtrl', function($scope, $stateParams, Friends) {
  $scope.friend = Friends.get($stateParams.friendId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});
