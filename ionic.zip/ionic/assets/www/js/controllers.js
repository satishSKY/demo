angular.module('starter.controllers', [])
.constant('$ionicLoadingConfig', {
    template: 'Please wait....'
  })
.controller('AppCtrl', function($scope, $state, $ionicModal) {
    
    $ionicModal.fromTemplateUrl('templates/login.html', function(modal) {
        $scope.loginModal = modal;
      },
      {
        scope: $scope,
        animation: 'slide-in-up',
        focusFirstInput: true
      }
    );
    //Be sure to cleanup the modal by removing it from the DOM
    $scope.$on('$destroy', function() {
      $scope.loginModal.remove();
    });
  })
    
.controller('LoginCtrl', function($scope,$state,$ionicPopup,baseUrl,AuthenticationService) {
    $scope.user = {
            username: null,
            password: null
          };
    $scope.signIn = function(user) {
        
        if(user.username === null || user.password === null){
            var alertPopup = $ionicPopup.alert({
                title: 'Medassure',
                template: 'Invalid username or password'
              });
              alertPopup.then(function(res) {
                console.log('Login Failed');
              });   
        }else{
            console.log(baseUrl.get()+'UserService.svc/auth');
            AuthenticationService.login(user,baseUrl.get()+'UserService.svc/auth');
            //$state.go('eventmenu.home');
        }
    }; 
    
    $scope.signUp = function() {
        $state.go('eventmenu.signup');
    };

})

.controller('forgotpasswordCtrl', function($scope) {
})
.controller('SignupCtrl', function($scope,$state) {
    $scope.backBtn = function(){
         $state.go('login');
    };
})

.controller('HomeCtrl', function($scope) {
})
.controller('LocationCtrl', function($scope) {
})
.controller('PreferenceCtrl', function($scope) {
})
.controller('AboutCtrl', function($scope) {
});


