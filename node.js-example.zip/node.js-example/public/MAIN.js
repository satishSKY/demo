module.exports = function(POOL,moment) {   
	"use strict";
	var MAIN = {
			localVar:{
				SOCKETS_ID: {}, // user id as main object
				SOCKETS_ID_ONLINE: {}, //socket id as main object
			},//localVar

			login: function(authData,socket,moment,callBack){
				var queryString = 'SELECT * FROM `ezt_all_user_info` WHERE UserId="'+authData.userId+'"';
				POOL.getConnection(function(Err, connection) {
					connection.query(queryString, function(err, rows, fields) {
						if (!err && rows.length > 0) {
							var row = rows[0];
							var this_id = row['UserId'];
							callBack(rows,true);
							connection.release();

						}else{
							connection.release();
							callBack(rows,false);
							console.log("db login err -->"+err);
						}
					});
				});
			},//login

			onPrivateMessages: function(io,socket,fs,data,callBack){  //only for text
				var self_ID = data.toId,
				toName = data.toName,
				message = data.message,
				userId = data.fromId,
				fromName = data.fromName;

				var SOCKETS_ID = MAIN.localVar.SOCKETS_ID;
				try{
					if(SOCKETS_ID.hasOwnProperty(self_ID) === false){//user is offline
						//self_ID is sender id and userId is receiver id and msg
						data.isPending = 0;
						MAIN.onOffline_Messeging(data,function(callJson){
							callBack(2);    
						});        
					}else{
						var sockID = SOCKETS_ID[userId].socket_ids;
						var self_socket = SOCKETS_ID[self_ID].socket_ids;
						console.log(self_ID+' : I received a private message by :  ', userId, '  : saying : ', message);
						data.status = SOCKETS_ID.hasOwnProperty(userId);
						socket.broadcast.to(self_socket).volatile.emit('privateMessage', data);
						data.isPending = 1;
						MAIN.onOffline_Messeging(data,function(callJson){
							callBack(1);    
						});
					}
				}catch(e){
					callBack(0);
				}
			},//onPrivateMessages



			onOffline_Messeging: function(data, callBack){
				POOL.getConnection(function(Err, connection) {
					var newUser_msg = 'INSERT INTO `ezt_chat` (ChatJobId, ChatFromUserId, 	ChatToUserId , ChatMessage , ChatCreatedAt ,	ChatMessageStatus)'
						+'VALUES ("'+data.chatJobId+'","'+data.fromId+'","'+data.toId+'","'+data.message+'","'+MAIN.getCurrentTime(12)+'","'+data.isPending+'")';
					connection.query(newUser_msg, function(err, rows, fields) {
						if (!err) {

							var inserted_id = rows.insertId;
							console.log('Successfully inserted row with id='+inserted_id+'.');
							connection.release();
							callBack({"success":1});
						}else{
							console.log('error'+err);
							connection.release();
							callBack({"success":0});
						}
					}); 
				});
			},//onOffline_Messeging

			sendPandingMessages: function(io,socket,receiverID,fs){

				var queryString =  "SELECT ezt_chat.*, C1.UserFullName AS FromName, C2.UserFullName AS ToName"
					+" FROM ezt_chat"
					+" JOIN ezt_all_user_info AS C1 ON ezt_chat.ChatFromUserId = C1.UserId"
					+" JOIN ezt_all_user_info AS C2 ON ezt_chat.ChatToUserId = C2.UserId"
					+" WHERE ChatMessageStatus = '"+0+"'"
					+" AND ChatToUserId = '"+receiverID+"'";  

				var sql_cmd = 'UPDATE `ezt_chat` SET ChatMessageStatus="1" WHERE 	`ChatToUserId`="'+receiverID+'"';

				POOL.getConnection(function(Err, connection) {
					connection.query(queryString, function(err, rows, fields) {
						if (!err && rows.length > 0) {
							for(var int=0 in rows){
								var row = rows[int];
								var jsonData = {'message': row['ChatMessage'],'toId':receiverID,'toName':row['ToName'],'fromId':row['ChatFromUserId'],'fromName': row['FromName']};
								console.log("sendPandingMessages  ==> "+ row['ChatMessage']);
								io.sockets.in(socket.id).emit('privateMessage', jsonData);
								connection.query(sql_cmd, function(errrr, newrows, fields_up) {
									//connection.release();
								});
							}//for
						}else{
							console.log('no pendding msg ====> '+err);
							connection.release();
						}
					});
				});
			},//sendPandingMessagesremoveGroup

			chatHistory: function(data,callback) {
				var page = data.pageId;
				if(parseInt(data.limit) === 0) data.limit = 10;

				if(parseInt(page) === 0) page = 1;
				var startLimit = (page-1)*parseInt(data.limit);

				var qry_chat = 'SELECT  `ChatId`,`ChatMessage`,`ChatCreatedAt`,`ChatToUserId` ,`ChatFromUserId` FROM `ezt_chat` WHERE `ChatFromUserId`="'+data.userId+'"  AND `ChatToUserId	`="'+data.to_user+'"  OR `ChatToUserId`="'+data.userId+'"  AND `ChatFromUserId`="'+data.to_user+'"   order by ChatId desc LIMIT '+startLimit+','+data.limit+'';
				POOL.getConnection(function(Err, connection) {
					connection.query(qry_chat, function(err, rows, fields) {
						if (!err) {
							connection.release();
							callback({'success': 1,'records':rows});
						}else{
							console.log(err);
							callback({'success': 0,'records':rows});
						}
					});
				});
			},//chatHistory



			myChatUserInfo: function(usrId,moment,callBack) {
				var qry = 'SELECT * FROM `ezt_all_user_info` WHERE UserId = "'+usrId+'" ';
				POOL.getConnection(function(Err, connection) {
					connection.query(qry, function(err, rows, fields) {
						try{
							console.log(rows);
							var row = rows[0];
							connection.release();
							callBack({"success":1,"lastLogin":row});
						}catch (e) {
							console.log(e);
						}
					})
				});
			},//myChatUserInfo

			disconnectUser: function(io,socket,moment){
				var olu = MAIN.localVar.SOCKETS_ID,
				olu_Online = MAIN.localVar.SOCKETS_ID_ONLINE,
				name,id;
				if(olu_Online.hasOwnProperty(socket.id) === true){
					console.log(" Disconnected user ==> "+ olu_Online[socket.id].user_id);
					id = olu_Online[socket.id].user_id;
					name = olu_Online[socket.id].name;
				}
				delete olu_Online[socket.id];
				delete olu[id];
				console.log(Object.keys(olu_Online).length+' <==SOCKETS_ID user:==> '+Object.keys(olu).length);
				//io.to(roomName[x]).emit('onlineStatus',  {'firstName':name,'id':id,'status': 0} );//ofline online
			},//disconnectUser

			getCurrentTime: function(format){
				var b = moment.utc();
				var TIMEFORMATE_YMD = b.format();
				if(format === 12) return TIMEFORMATE_YMD;
			}
	}
	return MAIN;
}








