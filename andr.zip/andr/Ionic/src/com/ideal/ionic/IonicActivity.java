package com.ideal.ionic;

import org.apache.cordova.CordovaActivity;
import org.apache.cordova.CordovaPlugin;



import android.os.Bundle;

public class IonicActivity extends CordovaActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	   super.onCreate(savedInstanceState);
           super.init();
           // Set by <content src="index.html" /> in config.xml
           loadUrl(launchUrl);
    }
}
