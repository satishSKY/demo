package com.it.geofence;

import org.apache.cordova.CordovaActivity;
import android.os.Bundle;
public class GeofenceActivity extends CordovaActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	 super.onCreate(savedInstanceState);
         super.init();
         // Set by <content src="index.html" /> in config.xml
         loadUrl(launchUrl);
    }
}
