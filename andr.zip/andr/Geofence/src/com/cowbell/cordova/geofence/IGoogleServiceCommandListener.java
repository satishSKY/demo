package com.cowbell.cordova.geofence;

public interface IGoogleServiceCommandListener {
    public void onCommandExecuted();
}
