cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
{
    "file": "plugins/com.ionic.keyboard/www/keyboard.js",
    "id": "com.ionic.keyboard.keyboard",
    "clobbers": [
        "cordova.plugins.Keyboard"
    ]
},
    {
        "file": "plugins/com.cowbell.cordova.geofence/www/TransitionType.js",
        "id": "com.cowbell.cordova.geofence.TransitionType",
        "clobbers": [
            "TransitionType"
        ]
    },
    {
        "file": "plugins/com.cowbell.cordova.geofence/www/geofence.js",
        "id": "com.cowbell.cordova.geofence.geofence",
        "clobbers": [
            "geofence"
        ]
    },
    {
        "file": "plugins/com.borismus.webintent/www/webintent.js",
        "id": "com.borismus.webintent.WebIntent",
        "clobbers": [
            "WebIntent"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.device/www/device.js",
        "id": "org.apache.cordova.device.device",
        "clobbers": [
            "device"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.network-information/www/network.js",
        "id": "org.apache.cordova.network-information.network",
        "clobbers": [
            "navigator.connection",
            "navigator.network.connection"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.network-information/www/Connection.js",
        "id": "org.apache.cordova.network-information.Connection",
        "clobbers": [
            "Connection"
        ]
    },
    {
        "file": "plugins/com.vladstirbu.cordova.promise/www/promise.js",
        "id": "com.vladstirbu.cordova.promise.Promise",
        "clobbers": [
            "Promise"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.geolocation/www/Coordinates.js",
        "id": "org.apache.cordova.geolocation.Coordinates",
        "clobbers": [
            "Coordinates"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.geolocation/www/PositionError.js",
        "id": "org.apache.cordova.geolocation.PositionError",
        "clobbers": [
            "PositionError"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.geolocation/www/Position.js",
        "id": "org.apache.cordova.geolocation.Position",
        "clobbers": [
            "Position"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.geolocation/www/geolocation.js",
        "id": "org.apache.cordova.geolocation.geolocation",
        "clobbers": [
            "navigator.geolocation"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
     "com.ionic.keyboard": "1.0.3",
    "com.cowbell.cordova.geofence": "0.3.3",
    "com.borismus.webintent": "1.0.0",
    "org.apache.cordova.device": "0.3.0",
    "org.apache.cordova.console": "0.2.13",
    "org.apache.cordova.network-information": "0.2.15",
    "com.vladstirbu.cordova.promise": "1.0.0",
    "com.google.playservices": "21.0.0",
    "org.apache.cordova.geolocation": "0.3.10"
}
// BOTTOM OF METADATA
});